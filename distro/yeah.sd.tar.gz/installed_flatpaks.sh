flatpak install --system com.discordapp.Discord -y
flatpak install --system com.discordapp.DiscordCanary -y
flatpak install --system com.spotify.Client -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.videolan.VLC -y

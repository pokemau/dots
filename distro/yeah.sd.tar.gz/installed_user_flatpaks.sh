flatpak install --user com.github.IsmaelMartinez.teams_for_linux -y
flatpak install --user com.mattjakeman.ExtensionManager -y

flatpak install --system com.github.IsmaelMartinez.teams_for_linux -y
flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system com.spotify.Client -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.videolan.VLC -y
flatpak install --system rest.insomnia.Insomnia -y

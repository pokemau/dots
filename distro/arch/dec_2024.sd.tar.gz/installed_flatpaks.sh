flatpak install --system com.github.IsmaelMartinez.teams_for_linux -y
flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
